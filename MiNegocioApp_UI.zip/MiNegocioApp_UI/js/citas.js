const citas = [
  {hora:"09:00", cliente:"Cliente A", nota:"Corte + barba", estado:"Confirmada"},
  {hora:"10:30", cliente:"Cliente B", nota:"Solo corte", estado:"Pendiente"},
  {hora:"12:00", cliente:"(Interno)", nota:"Bloqueado", estado:"Bloqueado"},
  {hora:"16:00", cliente:"Cliente C", nota:"Corte", estado:"Confirmada"},
];

function renderCitas(){
  const tbody = document.querySelector("#tablaCitas tbody");
  tbody.innerHTML = "";
  citas.forEach(c=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${c.hora}</td><td>${c.cliente}</td><td>${c.nota}</td><td>${c.estado}</td>`;
    tbody.appendChild(tr);
  });
}
renderCitas();

document.getElementById("btnNuevaCita").onclick = () => {
  citas.push({hora:"17:30", cliente:"Cliente Demo", nota:"Nueva cita", estado:"Pendiente"});
  renderCitas();
};

document.getElementById("btnBloquear").onclick = () => {
  citas.push({hora:"14:00", cliente:"(Interno)", nota:"Bloqueado", estado:"Bloqueado"});
  renderCitas();
};

document.getElementById("btnCancelar").onclick = () => {
  const i = citas.findIndex(x=>x.hora==="10:30");
  if(i>=0) citas[i].estado = "Cancelada";
  renderCitas();
};
