let ingresosDia = 0;

const catalogo = [
  {nombre:"Corte de cabello", tipo:"Servicio", precio:120},
  {nombre:"Barba", tipo:"Servicio", precio:80},
  {nombre:"Shampoo 250ml", tipo:"Artículo", precio:95},
  {nombre:"Cera para cabello", tipo:"Artículo", precio:110},
];

const carrito = [];

function money(n){ return `$ ${n.toLocaleString("es-MX")}`; }

function renderCatalogo(){
  const tbody = document.querySelector("#tablaCatalogo tbody");
  tbody.innerHTML = "";
  catalogo.forEach((p, idx)=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${p.nombre}</td>
      <td>${p.tipo}</td>
      <td>${money(p.precio)}</td>
      <td><button class="btn-sm" data-add="${idx}">Agregar</button></td>
    `;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll("[data-add]").forEach(b=>{
    b.onclick = ()=>{ carrito.push(catalogo[Number(b.dataset.add)]); renderCarrito(); };
  });
}

function renderCarrito(){
  const tbody = document.querySelector("#tablaCarrito tbody");
  tbody.innerHTML = "";
  carrito.forEach((it, idx)=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${it.nombre}</td>
      <td>${money(it.precio)}</td>
      <td><button class="btn-sm" data-del="${idx}">X</button></td>
    `;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll("[data-del]").forEach(b=>{
    b.onclick = ()=>{ carrito.splice(Number(b.dataset.del),1); renderCarrito(); };
  });

  const total = carrito.reduce((a,b)=>a+b.precio,0);
  document.getElementById("total").textContent = money(total);
  document.getElementById("mTotal").textContent = money(total);
}

renderCatalogo();
renderCarrito();
document.getElementById("ingresosDia").textContent = money(ingresosDia);

// modal
const backdrop = document.getElementById("backdrop");
const abrir = ()=> backdrop.style.display="flex";
const cerrar = ()=> backdrop.style.display="none";

document.getElementById("btnCobrar").onclick = ()=>{
  if(!carrito.length) return alert("Carrito vacío (demo).");
  document.getElementById("mRecibido").value = "";
  document.getElementById("mCambio").textContent = "$ 0";
  abrir();
};

document.getElementById("btnVaciar").onclick = ()=>{ carrito.length=0; renderCarrito(); };

document.getElementById("cerrar").onclick = cerrar;
document.getElementById("cancelar").onclick = cerrar;

function calcCambio(){
  const total = carrito.reduce((a,b)=>a+b.precio,0);
  const rec = Number(document.getElementById("mRecibido").value || 0);
  const cambio = Math.max(0, rec - total);
  document.getElementById("mCambio").textContent = money(cambio);
}
document.getElementById("mRecibido").addEventListener("input", calcCambio);

document.getElementById("keypad").addEventListener("click",(e)=>{
  if(e.target.tagName!=="BUTTON") return;
  const v = e.target.textContent;
  const inp = document.getElementById("mRecibido");
  if(v==="C") inp.value="";
  else if(v==="←") inp.value = inp.value.slice(0,-1);
  else inp.value += v;
  calcCambio();
});

document.getElementById("confirmar").onclick = ()=>{
  const total = carrito.reduce((a,b)=>a+b.precio,0);
  const rec = Number(document.getElementById("mRecibido").value || 0);
  if(rec < total) return alert("Pago insuficiente (demo).");
  ingresosDia += total;
  document.getElementById("ingresosDia").textContent = money(ingresosDia);
  carrito.length=0;
  renderCarrito();
  cerrar();
  alert("Venta registrada (demo).");
};
/* ============ CALCULADORA POS (DEMO) ============ */

let inputMonto = "";
const totalVenta = 450;

function abrirCobro() {
  document.getElementById("modalCobro").style.display = "flex";
  inputMonto = "";
  actualizarPantalla();
}

function cerrarCobro() {
  document.getElementById("modalCobro").style.display = "none";
}

function agregarNumero(num) {
  inputMonto += num;
  actualizarPantalla();
}

function borrar() {
  inputMonto = inputMonto.slice(0, -1);
  actualizarPantalla();
}

function limpiar() {
  inputMonto = "";
  actualizarPantalla();
}

function actualizarPantalla() {
  const recibido = Number(inputMonto || 0);
  const cambio = Math.max(0, recibido - totalVenta);

  document.getElementById("montoRecibido").textContent =
    `$${recibido.toFixed(2)}`;

  document.getElementById("cambio").textContent =
    `$${cambio.toFixed(2)}`;
}

/* =============================================== */
